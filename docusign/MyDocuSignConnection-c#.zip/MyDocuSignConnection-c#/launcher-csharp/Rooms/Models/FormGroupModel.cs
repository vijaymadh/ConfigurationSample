﻿namespace DocuSign.CodeExamples.Rooms.Models
{
    public class FormGroupModel
    {
        public string Name { get; set; }
    }
}
