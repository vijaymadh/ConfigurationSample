# DocuSign.eSign.Model.ApiRequestLogsResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApiRequestLogs** | [**List&lt;ApiRequestLog&gt;**](ApiRequestLog.md) | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

