# DocuSign.eSign.Model.UserInfoResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeId** | **string** | The envelope ID of the envelope status that failed to post. | [optional] 
**Language** | **string** |  | [optional] 
**Seal** | [**Seal**](Seal.md) |  | [optional] 
**Sender** | [**Sender**](Sender.md) |  | [optional] 
**User** | [**User**](User.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

