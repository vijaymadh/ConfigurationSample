# DocuSign.eSign.Model.RecipientSAMLAuthentication
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SamlAssertionAttributes** | [**List&lt;SamlAssertionAttribute&gt;**](SamlAssertionAttribute.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

