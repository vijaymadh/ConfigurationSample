# DocuSign.eSign.Model.User
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CountryCode** | **string** |  | [optional] 
**Credentials** | [**List&lt;Credential&gt;**](Credential.md) |  | [optional] 
**DisplayName** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

