# DocuSign.eSign.Model.BrandsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Brands** | [**List&lt;BrandRequest&gt;**](BrandRequest.md) | The list of brands. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

