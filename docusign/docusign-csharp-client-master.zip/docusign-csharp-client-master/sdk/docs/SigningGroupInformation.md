# DocuSign.eSign.Model.SigningGroupInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Groups** | [**List&lt;SigningGroup&gt;**](SigningGroup.md) | A collection group objects containing information about the groups returned. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

