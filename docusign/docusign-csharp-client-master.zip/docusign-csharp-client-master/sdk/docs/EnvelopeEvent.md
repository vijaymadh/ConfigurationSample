# DocuSign.eSign.Model.EnvelopeEvent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeEventStatusCode** | **string** | he envelope status, this can be Sent, Delivered, Completed, Declined, or Voided. | [optional] 
**IncludeDocuments** | **string** | When set to **true**, the PDF documents are included in the message along with the updated XML.  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

