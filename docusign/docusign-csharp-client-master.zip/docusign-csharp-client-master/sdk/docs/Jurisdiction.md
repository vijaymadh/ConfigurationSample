# DocuSign.eSign.Model.Jurisdiction
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CommissionIdInSeal** | **string** |  | [optional] 
**County** | **string** |  | [optional] 
**CountyInSeal** | **string** |  | [optional] 
**Enabled** | **string** |  | [optional] 
**JurisdictionId** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**NotaryPublicInSeal** | **string** |  | [optional] 
**StateNameInSeal** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

