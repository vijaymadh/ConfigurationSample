# DocuSign.eSign.Model.CreditCardTypes
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CardTypes** | **List&lt;string&gt;** | An array containing supported credit card types. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

