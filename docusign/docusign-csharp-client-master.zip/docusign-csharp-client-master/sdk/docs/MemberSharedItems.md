# DocuSign.eSign.Model.MemberSharedItems
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Envelopes** | [**List&lt;SharedItem&gt;**](SharedItem.md) |  | [optional] 
**ErrorDetails** | [**ErrorDetails**](ErrorDetails.md) |  | [optional] 
**Templates** | [**List&lt;TemplateSharedItem&gt;**](TemplateSharedItem.md) |  | [optional] 
**User** | [**UserInfo**](UserInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

