# DocuSign.eSign.Model.BillingPaymentRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PaymentAmount** | **string** | The payment amount for the past due invoices. This value must match the pastDueBalance value retrieved using Get Past Due Invoices. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

