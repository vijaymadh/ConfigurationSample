# DocuSign.eSign.Model.BrandEmailContent
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Content** | **string** |  | [optional] 
**EmailContentType** | **string** |  | [optional] 
**EmailToLink** | **string** |  | [optional] 
**LinkText** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

