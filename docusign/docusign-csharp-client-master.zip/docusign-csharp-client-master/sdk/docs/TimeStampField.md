# DocuSign.eSign.Model.TimeStampField
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentSecurityStore** | [**DocumentSecurityStore**](DocumentSecurityStore.md) |  | [optional] 
**MaxTimeStampSignatureLength** | **string** |  | [optional] 
**TimeStampFieldName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

