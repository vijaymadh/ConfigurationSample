# DocuSign.eSign.Model.UpdateTransactionRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Code** | **string** |  | [optional] 
**Message** | **string** |  | [optional] 
**State** | **string** | The state or province associated with the address. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

