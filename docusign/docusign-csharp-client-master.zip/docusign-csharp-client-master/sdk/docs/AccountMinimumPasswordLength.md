# DocuSign.eSign.Model.AccountMinimumPasswordLength
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MaximumLength** | **string** |  | [optional] 
**MinimumLength** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

