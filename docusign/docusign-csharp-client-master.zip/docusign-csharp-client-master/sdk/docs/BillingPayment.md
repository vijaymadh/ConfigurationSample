# DocuSign.eSign.Model.BillingPayment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Amount** | **string** | Reserved: TBD | [optional] 
**InvoiceId** | **string** | Reserved: TBD | [optional] 
**PaymentId** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

