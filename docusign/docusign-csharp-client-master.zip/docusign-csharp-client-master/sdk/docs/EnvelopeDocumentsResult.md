# DocuSign.eSign.Model.EnvelopeDocumentsResult
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeDocuments** | [**List&lt;EnvelopeDocument&gt;**](EnvelopeDocument.md) |  | [optional] 
**EnvelopeId** | **string** | The envelope ID of the envelope status that failed to post. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

