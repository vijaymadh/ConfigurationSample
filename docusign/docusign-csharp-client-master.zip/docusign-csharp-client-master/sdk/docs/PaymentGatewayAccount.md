# DocuSign.eSign.Model.PaymentGatewayAccount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisplayName** | **string** |  | [optional] 
**PaymentGateway** | **string** |  | [optional] 
**PaymentGatewayAccountId** | **string** |  | [optional] 
**PaymentGatewayDisplayName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

