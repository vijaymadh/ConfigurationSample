# DocuSign.eSign.Model.NotaryJournalMetaData
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Comment** | **string** |  | [optional] 
**CredibleWitnesses** | [**List&lt;NotaryJournalCredibleWitness&gt;**](NotaryJournalCredibleWitness.md) |  | [optional] 
**SignatureImage** | **string** |  | [optional] 
**SignerIdType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

