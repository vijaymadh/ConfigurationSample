# DocuSign.eSign.Model.ConnectFailureFilter
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeIds** | **List&lt;string&gt;** |  | [optional] 
**Synchronous** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

