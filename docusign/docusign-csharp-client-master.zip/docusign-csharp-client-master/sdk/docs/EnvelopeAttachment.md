# DocuSign.eSign.Model.EnvelopeAttachment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessControl** | **string** |  | [optional] 
**AttachmentId** | **string** |  | [optional] 
**AttachmentType** | **string** |  | [optional] 
**ErrorDetails** | [**ErrorDetails**](ErrorDetails.md) |  | [optional] 
**Label** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

