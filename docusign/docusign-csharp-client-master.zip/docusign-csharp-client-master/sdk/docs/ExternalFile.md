# DocuSign.eSign.Model.ExternalFile
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Date** | **string** |  | [optional] 
**Id** | **string** |  | [optional] 
**Img** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Size** | **string** | Reserved: TBD | [optional] 
**Supported** | **string** |  | [optional] 
**Type** | **string** |  | [optional] 
**Uri** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

