# DocuSign.eSign.Model.DiagnosticsSettingsInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ApiRequestLogging** | **string** |  When set to **true**, enables API request logging for the user.  | [optional] 
**ApiRequestLogMaxEntries** | **string** | Specifies the maximum number of API requests to log. | [optional] 
**ApiRequestLogRemainingEntries** | **string** | Indicates the remaining number of API requests that can be logged. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

