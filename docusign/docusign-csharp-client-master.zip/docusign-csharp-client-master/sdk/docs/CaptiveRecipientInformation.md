# DocuSign.eSign.Model.CaptiveRecipientInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CaptiveRecipients** | [**List&lt;CaptiveRecipient&gt;**](CaptiveRecipient.md) | A complex type containing information about one or more captive recipients. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

