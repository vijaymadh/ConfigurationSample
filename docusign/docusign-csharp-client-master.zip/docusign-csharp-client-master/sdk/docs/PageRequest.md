# DocuSign.eSign.Model.PageRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Password** | **string** |  | [optional] 
**Rotate** | **string** | Sets the direction the page image is rotated. The possible settings are: left or right | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

