# DocuSign.eSign.Model.AccountSignatureProviders
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SignatureProviders** | [**List&lt;AccountSignatureProvider&gt;**](AccountSignatureProvider.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

