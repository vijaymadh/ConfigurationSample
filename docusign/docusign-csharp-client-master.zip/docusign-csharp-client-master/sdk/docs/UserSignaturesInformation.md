# DocuSign.eSign.Model.UserSignaturesInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**UserSignatures** | [**List&lt;UserSignature&gt;**](UserSignature.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

