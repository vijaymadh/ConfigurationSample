# DocuSign.eSign.Model.AppStoreProduct
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MarketPlace** | **string** |  | [optional] 
**ProductId** | **string** | The Product ID from the AppStore. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

