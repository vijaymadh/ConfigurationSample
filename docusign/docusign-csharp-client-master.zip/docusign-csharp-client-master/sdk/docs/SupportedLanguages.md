# DocuSign.eSign.Model.SupportedLanguages
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Languages** | [**List&lt;NameValue&gt;**](NameValue.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

