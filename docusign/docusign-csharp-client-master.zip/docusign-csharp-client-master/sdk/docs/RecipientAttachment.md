# DocuSign.eSign.Model.RecipientAttachment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AttachmentId** | **string** |  | [optional] 
**AttachmentType** | **string** |  | [optional] 
**Data** | **string** |  | [optional] 
**Label** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**RemoteUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

