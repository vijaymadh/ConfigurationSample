# DocuSign.eSign.Model.EnvelopeNotificationRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Expirations** | [**Expirations**](Expirations.md) |  | [optional] 
**Reminders** | [**Reminders**](Reminders.md) |  | [optional] 
**UseAccountDefaults** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

