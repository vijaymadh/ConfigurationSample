# DocuSign.eSign.Model.CloudStorageProviders
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**StorageProviders** | [**List&lt;CloudStorageProvider&gt;**](CloudStorageProvider.md) | An Array containing the storage providers associated with the user. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

