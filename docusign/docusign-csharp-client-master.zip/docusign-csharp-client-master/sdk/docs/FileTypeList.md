# DocuSign.eSign.Model.FileTypeList
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FileTypes** | [**List&lt;FileType&gt;**](FileType.md) | A collection of file types. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

