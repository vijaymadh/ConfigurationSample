# DocuSign.eSign.Model.IdCheckInformationInput
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AddressInformationInput** | [**AddressInformationInput**](AddressInformationInput.md) |  | [optional] 
**DobInformationInput** | [**DobInformationInput**](DobInformationInput.md) |  | [optional] 
**Ssn4InformationInput** | [**Ssn4InformationInput**](Ssn4InformationInput.md) |  | [optional] 
**Ssn9InformationInput** | [**Ssn9InformationInput**](Ssn9InformationInput.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

