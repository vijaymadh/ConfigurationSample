# DocuSign.eSign.Model.BillingInvoiceItem
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ChargeAmount** | **string** | Reserved: TBD | [optional] 
**ChargeName** | **string** | Reserved: TBD | [optional] 
**InvoiceItemId** | **string** | Reserved: TBD | [optional] 
**Quantity** | **string** |  | [optional] 
**UnitPrice** | **string** | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

