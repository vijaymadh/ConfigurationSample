# DocuSign.eSign.Model.BrandResourceUrls
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Email** | **string** |  | [optional] 
**Sending** | **string** |  | [optional] 
**Signing** | **string** |  | [optional] 
**SigningCaptive** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

