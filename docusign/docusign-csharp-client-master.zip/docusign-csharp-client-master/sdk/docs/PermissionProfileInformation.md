# DocuSign.eSign.Model.PermissionProfileInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**PermissionProfiles** | [**List&lt;PermissionProfile&gt;**](PermissionProfile.md) | A complex type containing a collection of permission profiles. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

