# DocuSign.eSign.Model.BillingChargeResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BillingChargeItems** | [**List&lt;BillingCharge&gt;**](BillingCharge.md) | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

