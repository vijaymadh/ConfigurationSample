# DocuSign.eSign.Model.BrandLink
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**LinkText** | **string** |  | [optional] 
**LinkType** | **string** |  | [optional] 
**ShowLink** | **string** |  | [optional] 
**UrlOrMailTo** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

