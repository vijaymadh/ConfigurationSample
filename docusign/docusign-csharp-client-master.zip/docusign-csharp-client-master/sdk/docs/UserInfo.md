# DocuSign.eSign.Model.UserInfo
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ActivationAccessCode** | **string** |  | [optional] 
**Email** | **string** |  | [optional] 
**ErrorDetails** | [**ErrorDetails**](ErrorDetails.md) |  | [optional] 
**LoginStatus** | **string** |  | [optional] 
**SendActivationEmail** | **string** |  | [optional] 
**Uri** | **string** |  | [optional] 
**UserId** | **string** |  | [optional] 
**UserName** | **string** |  | [optional] 
**UserStatus** | **string** |  | [optional] 
**UserType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

