# DocuSign.eSign.Model.FoldersRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeIds** | **List&lt;string&gt;** |  | [optional] 
**FromFolderId** | **string** |  The folder ID the envelope is being moved from. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

