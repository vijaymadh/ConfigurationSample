# DocuSign.eSign.Model.ConnectDebugLog
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ConnectConfig** | **string** |  | [optional] 
**ErrorDetails** | [**ErrorDetails**](ErrorDetails.md) |  | [optional] 
**EventDateTime** | **string** |  | [optional] 
**EventDescription** | **string** |  | [optional] 
**Payload** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

