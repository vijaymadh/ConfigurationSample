# DocuSign.eSign.Model.SettingsMetadata
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Is21CFRPart11** | **string** | When set to **true**, indicates that this module is enabled on the account. | [optional] 
**Options** | **List&lt;string&gt;** |  | [optional] 
**Rights** | **string** |  | [optional] 
**UiHint** | **string** |  | [optional] 
**UiOrder** | **string** |  | [optional] 
**UiType** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

