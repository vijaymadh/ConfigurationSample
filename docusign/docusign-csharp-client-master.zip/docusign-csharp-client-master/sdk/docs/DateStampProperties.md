# DocuSign.eSign.Model.DateStampProperties
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DateAreaHeight** | **string** |  | [optional] 
**DateAreaWidth** | **string** |  | [optional] 
**DateAreaX** | **string** |  | [optional] 
**DateAreaY** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

