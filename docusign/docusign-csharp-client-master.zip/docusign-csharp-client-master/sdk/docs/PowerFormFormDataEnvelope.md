# DocuSign.eSign.Model.PowerFormFormDataEnvelope
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeId** | **string** | The envelope ID of the envelope status that failed to post. | [optional] 
**Recipients** | [**List&lt;PowerFormFormDataRecipient&gt;**](PowerFormFormDataRecipient.md) | An array of powerform recipients. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

