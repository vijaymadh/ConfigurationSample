# DocuSign.eSign.Model.BillingPlanResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BillingPlan** | [**BillingPlan**](BillingPlan.md) |  | [optional] 
**SuccessorPlans** | [**List&lt;BillingPlan&gt;**](BillingPlan.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

