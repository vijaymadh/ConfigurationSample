# DocuSign.eSign.Model.BillingPrice
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BeginQuantity** | **string** | Reserved: TBD | [optional] 
**EndQuantity** | **string** |  | [optional] 
**UnitPrice** | **string** | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

