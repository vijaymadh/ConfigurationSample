# DocuSign.eSign.Model.RecipientSignatureProviderOptions
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CpfNumber** | **string** |  | [optional] 
**OneTimePassword** | **string** |  | [optional] 
**SignerRole** | **string** |  | [optional] 
**Sms** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

