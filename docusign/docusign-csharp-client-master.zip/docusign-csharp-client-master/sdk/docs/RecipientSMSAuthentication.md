# DocuSign.eSign.Model.RecipientSMSAuthentication
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SenderProvidedNumbers** | **List&lt;string&gt;** | An Array containing a list of phone numbers the recipient may use for SMS text authentication.  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

