# DocuSign.eSign.Model.RecipientSignatureProvider
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**SealName** | **string** |  | [optional] 
**SignatureProviderName** | **string** |  | [optional] 
**SignatureProviderOptions** | [**RecipientSignatureProviderOptions**](RecipientSignatureProviderOptions.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

