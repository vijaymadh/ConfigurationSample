# DocuSign.eSign.Model.ServerTemplate
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Sequence** | **string** |  | [optional] 
**TemplateId** | **string** | The unique identifier of the template. If this is not provided, DocuSign will generate a value.  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

