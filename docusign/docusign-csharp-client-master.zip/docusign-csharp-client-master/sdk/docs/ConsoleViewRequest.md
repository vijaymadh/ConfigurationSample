# DocuSign.eSign.Model.ConsoleViewRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeId** | **string** | The envelope ID of the envelope status that failed to post. | [optional] 
**ReturnUrl** | **string** | The URL to be redirected to after the console view session has ended. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

