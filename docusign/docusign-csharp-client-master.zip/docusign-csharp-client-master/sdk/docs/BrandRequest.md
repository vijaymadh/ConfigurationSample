# DocuSign.eSign.Model.BrandRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BrandId** | **string** | The ID of the brand used in API calls | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

