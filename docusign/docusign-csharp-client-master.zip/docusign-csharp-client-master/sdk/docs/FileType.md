# DocuSign.eSign.Model.FileType
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**FileExtension** | **string** |  | [optional] 
**MimeType** | **string** | The mime-type of a file type listed in a fileTypes collection. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

