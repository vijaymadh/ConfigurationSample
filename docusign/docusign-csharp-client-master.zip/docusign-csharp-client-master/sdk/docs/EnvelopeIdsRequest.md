# DocuSign.eSign.Model.EnvelopeIdsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**EnvelopeIds** | **List&lt;string&gt;** |  | [optional] 
**TransactionIds** | **List&lt;string&gt;** |  A list of transaction Id&#39;s used to determining the status of envelopes sent asynchronously. See **transactionId** property on envelopes. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

