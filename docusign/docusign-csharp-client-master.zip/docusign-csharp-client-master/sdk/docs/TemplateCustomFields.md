# DocuSign.eSign.Model.TemplateCustomFields
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ListCustomFields** | [**List&lt;ListCustomField&gt;**](ListCustomField.md) | An array of list custom fields. | [optional] 
**TextCustomFields** | [**List&lt;TextCustomField&gt;**](TextCustomField.md) | An array of text custom fields. | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

