# DocuSign.eSign.Model.Country
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**IsoCode** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**Provinces** | [**List&lt;Province&gt;**](Province.md) |  | [optional] 
**ProvinceValidated** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

