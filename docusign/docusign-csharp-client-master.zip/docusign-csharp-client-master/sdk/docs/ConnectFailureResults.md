# DocuSign.eSign.Model.ConnectFailureResults
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**RetryQueue** | [**List&lt;ConnectFailureResult&gt;**](ConnectFailureResult.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

