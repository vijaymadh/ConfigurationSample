# DocuSign.eSign.Model.NotaryJournal
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedDate** | **string** |  | [optional] 
**DocumentName** | **string** |  | [optional] 
**Jurisdiction** | [**Jurisdiction**](Jurisdiction.md) |  | [optional] 
**NotaryJournalId** | **string** |  | [optional] 
**NotaryJournalMetaData** | [**NotaryJournalMetaData**](NotaryJournalMetaData.md) |  | [optional] 
**SignerName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

