# DocuSign.eSign.Model.SeatDiscount
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BeginSeatCount** | **string** | Reserved: TBD | [optional] 
**DiscountPercent** | **string** |  | [optional] 
**EndSeatCount** | **string** | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

