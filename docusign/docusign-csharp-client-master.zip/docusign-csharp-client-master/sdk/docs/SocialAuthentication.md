# DocuSign.eSign.Model.SocialAuthentication
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Authentication** | **string** | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

