# DocuSign.eSign.Model.UserSharedItem
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**ErrorDetails** | [**ErrorDetails**](ErrorDetails.md) |  | [optional] 
**Shared** | **string** | When set to **true**, this custom tab is shared. | [optional] 
**User** | [**UserInfo**](UserInfo.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

