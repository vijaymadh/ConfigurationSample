# DocuSign.eSign.Model.PowerFormsFormDataResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Envelopes** | [**List&lt;PowerFormFormDataEnvelope&gt;**](PowerFormFormDataEnvelope.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

