# DocuSign.eSign.Model.Ssn9InformationInput
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DisplayLevelCode** | **string** | Specifies the display level for the recipient.  Valid values are:   * ReadOnly * Editable * DoNotDisplay | [optional] 
**Ssn9** | **string** |  The recipient&#39;s Social Security Number(SSN). | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

