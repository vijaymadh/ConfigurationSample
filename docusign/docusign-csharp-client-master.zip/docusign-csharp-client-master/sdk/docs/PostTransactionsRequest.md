# DocuSign.eSign.Model.PostTransactionsRequest
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentData** | **string** |  | [optional] 
**DptName** | **string** |  | [optional] 
**TransactionName** | **string** |  | [optional] 
**TransactionTypeName** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

