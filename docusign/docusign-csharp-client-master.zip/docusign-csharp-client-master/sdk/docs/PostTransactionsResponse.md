# DocuSign.eSign.Model.PostTransactionsResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**DocumentData** | **string** |  | [optional] 
**TransactionSid** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

