# DocuSign.eSign.Model.BillingInvoicesSummary
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BillingInvoices** | [**List&lt;BillingInvoice&gt;**](BillingInvoice.md) | Reserved: TBD | [optional] 
**PastDueBalance** | **string** |  | [optional] 
**PaymentAllowed** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

