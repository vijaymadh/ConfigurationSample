# DocuSign.eSign.Model.BrandResources
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**CreatedByUserInfo** | [**UserInfo**](UserInfo.md) |  | [optional] 
**CreatedDate** | **string** |  | [optional] 
**ModifiedByUserInfo** | [**UserInfo**](UserInfo.md) |  | [optional] 
**ModifiedDate** | **string** |  | [optional] 
**ModifiedTemplates** | **List&lt;string&gt;** |  | [optional] 
**ResourcesContentType** | **string** |  | [optional] 
**ResourcesContentUri** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

