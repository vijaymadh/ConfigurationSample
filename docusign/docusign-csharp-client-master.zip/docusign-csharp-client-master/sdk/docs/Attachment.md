# DocuSign.eSign.Model.Attachment
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**AccessControl** | **string** |  | [optional] 
**AttachmentId** | **string** |  | [optional] 
**AttachmentType** | **string** | Specifies the type of the attachment for the recipient. | [optional] 
**Data** | **string** |  | [optional] 
**Label** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**RemoteUrl** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

