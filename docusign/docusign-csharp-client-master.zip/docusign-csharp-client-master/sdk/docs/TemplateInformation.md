# DocuSign.eSign.Model.TemplateInformation
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Templates** | [**List&lt;TemplateSummary&gt;**](TemplateSummary.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

