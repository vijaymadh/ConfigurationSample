# DocuSign.eSign.Model.AccountPasswordStrengthTypeOption
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**MinimumLength** | **string** |  | [optional] 
**Name** | **string** |  | [optional] 
**PasswordIncludeDigit** | **string** |  | [optional] 
**PasswordIncludeDigitOrSpecialCharacter** | **string** |  | [optional] 
**PasswordIncludeLowerCase** | **string** |  | [optional] 
**PasswordIncludeSpecialCharacter** | **string** |  | [optional] 
**PasswordIncludeUpperCase** | **string** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

