# DocuSign.eSign.Model.SigningGroupUsers
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**Users** | [**List&lt;SigningGroupUser&gt;**](SigningGroupUser.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

