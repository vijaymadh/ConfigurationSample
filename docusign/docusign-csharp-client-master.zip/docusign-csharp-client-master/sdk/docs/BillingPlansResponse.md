# DocuSign.eSign.Model.BillingPlansResponse
## Properties

Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**BillingPlans** | [**List&lt;BillingPlan&gt;**](BillingPlan.md) | Reserved: TBD | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)

