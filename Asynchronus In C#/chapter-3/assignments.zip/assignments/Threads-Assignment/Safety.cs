using System;
using System.Threading;

namespace assignments.ThreadsAssignment
{
    public class Safety
    {
        ///<summary>
        /// Make sure that all threads are ordered on the output!
        /// Use either a signaling construct or a lokcing mechanism to achieve this!
        ///</summary>
        public static void Run()
        {
            for (int i = 0; i < 10; i++)
            {
                var threadOne = new Thread(Signaling)
                {
                    Name = "thread " + i.ToString()
                };
                threadOne.Start();
            }
        }

        private static AutoResetEvent _handle = new AutoResetEvent(true);
        private static void Signaling()
        {
            var name = Thread.CurrentThread.Name;
            _handle.WaitOne();
            System.Console.WriteLine($"now incoming thread: {name}");
            _handle.Set();
        }
    }
}