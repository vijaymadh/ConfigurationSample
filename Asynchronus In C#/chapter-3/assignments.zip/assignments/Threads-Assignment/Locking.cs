using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading;

namespace assignments.ThreadsAssignment
{
    public class Locking
    {
        ///<summary>
        /// Make sure that only items from 0 to 9 end up in the collection 
        /// and this does not throw any exceptions
        ///</summary>
        public static void RunLock()
        {
            var inDanger = new InDanger();
            var list = new List<Thread>();

            int starter = 0;
            for (int i = 0; i < 100; i++)
            {
                starter = new Random().Next(0, 10);
                var thread = new Thread(() => AddToInDanger(inDanger))
                { 
                    Name = $"{starter}-Thread"
                };
                list.Add(thread);
            }
            foreach (var thread in list)
            {
                thread.Start();
            }
            System.Console.WriteLine("press to proceed...");
            Console.ReadLine();
            System.Console.WriteLine(inDanger);
        }

        private static object _locking = new object();
        ///<summary>
        /// Touch this code and make it atomic...
        ///</summary>
        private static void AddToInDanger(InDanger inDanger)
        {
            string currentName = Thread.CurrentThread.Name;
            lock (_locking)
            {
                if (!IsContained(inDanger, currentName))
                {
                    System.Console.WriteLine("not in here--> " + currentName);
                    inDanger.ThreadNames.Add(currentName);
                }
            }
        }

        # region dont touch
        private static bool IsContained(InDanger inDanger, string name)
        {
            // or use LINQ! --> Any
            int amount = inDanger.ThreadNames.Count;
            for (int i = 0; i < amount; i++)
            {
                if (inDanger.ThreadNames[i] == name)
                    return true;
            }
            return false;
        }

        public class InDanger
        {
            public List<string> ThreadNames { get; } = new List<string>();
            public override string ToString()
                => string.Join(", ", ThreadNames.OrderBy(x => x));
        }
        #endregion
    }
}