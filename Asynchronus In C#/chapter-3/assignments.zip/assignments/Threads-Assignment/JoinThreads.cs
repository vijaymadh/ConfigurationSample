using System;
using System.Linq;
using System.Threading;

namespace assignments.ThreadsAssignment
{
    public class JoinThreads
    {
        // private static bool isSignaled;
        public static void Run()
        {
            var rnd = new Random();
            for (int i = 0; i < 10; i++)
            {
                int next = rnd.Next(0, 1000);
                System.Console.WriteLine($"next calc time is [{next}] ms");
                // int timeOut = 400;
                
                // your code goes here!
            }
        }

        ///<summary>
        ///Simulates long running operation work in milliseconds
        ///</summary>
        public static void CalculateInThread(int nextCalcTimeInMs)
        {
            double divided = nextCalcTimeInMs/2.0d;
            var half = (int)Math.Floor(divided);
            Thread.Sleep(half);
            // check?
            Thread.Sleep(half);
        }
    }
}